package com.zx.util;

import javax.servlet.http.HttpSession;

public class UserUtil {
    public static String getUserName(HttpSession session){
        return(String) session.getAttribute("adminUserName");
    }
}
