package com.zx.util;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import javax.xml.transform.Result;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DruidUtil {

    private static DataSource ds;
    static{
        try {
            Properties ppt = new Properties();
//            InputStream is = new FileInputStream("src\\druid.properties");
            ppt.load(DruidUtil.class.getClassLoader().getResourceAsStream("druid.properties"));
//            ppt.load(is);
            ds = DruidDataSourceFactory.createDataSource(ppt);
            Connection conn=ds.getConnection();

            //6.操作数据库
            String sql = "select * from Admin";
            Statement stmt=conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                int password = rs.getInt("password");
                System.out.println(id + "  " + username + "  " + password);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws Exception {
        //1.导入jar包
        //2.定义配置文件
        //3. 加载配置文件
        Properties prop=new Properties();
        prop.load(DruidUtil.class.getClassLoader().getResourceAsStream("druid.properties"));

        //4. 获取连接池对象
        DataSource dataSource= DruidDataSourceFactory.createDataSource(prop);

        //5. 获取数据库连接 Connection
        Connection conn=dataSource.getConnection();

        //6.操作数据库
        String sql = "select * from Admin";
        Statement stmt=conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        while (rs.next()) {
            int id = rs.getInt("id");
            String username = rs.getString("username");
            int password = rs.getInt("password");
            System.out.println(id + "  " + username + "  " + password);
        }

    }


    /**
     * 从连接池中取出一个连接给用户
     * @return
     */
    public static Connection getConnection(){
        try {
            return ds.getConnection();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }


    public static void close(Connection conn, Statement state, ResultSet rs){
        try {
            if (rs != null) {
                rs.close();
            }

        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
        try {
            if(state!=null)
            state.close();
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
        try {
            conn.close();
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }
}
