package com.zx.util;

import com.google.gson.Gson;

public class JsonUtil {
    private static Gson g = new Gson();
    //把数据进行转换
    public static String toJson(Object o){
        return g.toJson(o);
    }

}
