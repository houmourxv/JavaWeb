package com.zx.controller;

import com.zx.bean.*;
import com.zx.mvc.ResponseBody;
import com.zx.service.CourierService;
import com.zx.util.DateFormatUtil;
import com.zx.util.JsonUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CourierController {
    @ResponseBody("/courier/console2.do")
    public String getConsole(HttpServletRequest request, HttpServletResponse response){
        Map<String,Integer> data = CourierService.getConsole();
        Message msg = new Message();
        if(data.size()>0){
           msg.setStatus(0);
           msg.setData(data);
        }else {
            msg.setStatus(-1);
        }
        String s = JsonUtil.toJson(msg);
        return s;
    }
    @ResponseBody("/Courier/list.do")
    public String list (HttpServletRequest request,HttpServletResponse response){
        int offset = Integer.parseInt(request.getParameter("offset"));
        int pageNumber=Integer.parseInt(request.getParameter("pageNumber"));
        List<Courier> list = CourierService.findAll(true,offset,pageNumber);
        List<BootstrapTableCourier> list2 = new ArrayList<>();
        for(Courier courier : list) {
            if (courier.getLastest_time() != null) {
                String lastest_time = DateFormatUtil.format(courier.getLastest_time());
                String register_time = DateFormatUtil.format(courier.getRegister_time());
                BootstrapTableCourier e = new BootstrapTableCourier(courier.getId(), courier.getUsername(), courier.getPassword(), courier.getIdCard(),  courier.getSendNum(), courier.getUserphone(),register_time, lastest_time);
                list2.add(e);
            } else {
                String lastest_time = "最近未登录";
                String register_time = DateFormatUtil.format(courier.getRegister_time());
                BootstrapTableCourier e = new BootstrapTableCourier(courier.getId(), courier.getUsername(), courier.getPassword(), courier.getIdCard(),  courier.getSendNum(), courier.getUserphone(),register_time, lastest_time);
                list2.add(e);
            }
        }
            int total = CourierService.getTotal();
            ResultData<BootstrapTableCourier> data = new ResultData<>();
            data.setTotal(total);
            data.setRows(list2);
            String s = JsonUtil.toJson(data);
            return s;
        }
    @ResponseBody("/Courier/insert.do")
    public String insert(HttpServletRequest request,HttpServletResponse response){
        String username = request.getParameter("username");
        String idCard = request.getParameter("idCard");
        String userphone = request.getParameter("userphone");
        String password = request.getParameter("password");
        Courier courier = new Courier(username,password,idCard,userphone);
        boolean insert = CourierService.insert(courier);
        Message msg = new Message();
        if(insert){
            msg.setStatus(0);
            msg.setResult("录入成功");
        }else {
            msg.setStatus(-1);
            msg.setResult("录入失败");
        }
        String s =JsonUtil.toJson(msg);
        return s;
    }
    @ResponseBody("/Courier/find.do")
    public String find(HttpServletRequest request,HttpServletResponse response){
        String userphone = request.getParameter("userphone");
        Courier c = CourierService.findByPhone(userphone);
        Message msg = new Message();
        if(c!=null){
            msg.setStatus(0);
            msg.setResult("查询成功");
            msg.setData(c);
        }else {
            msg.setStatus(-1);
            msg.setResult("查询失败");
        }
        String s =JsonUtil.toJson(msg);
        return s;
    }

    @ResponseBody("/Courier/update.do")
    public String update(HttpServletRequest request , HttpServletResponse response){
        int id = Integer.parseInt(request.getParameter("id"));
        String userphone = request.getParameter("userphone");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String idCard = request.getParameter("idCard");
        Courier c =new Courier(id,username,password,idCard,userphone);
        boolean update = CourierService.update(id,c);
        Message msg = new Message();
        if(update){
            msg.setStatus(0);
            msg.setResult("更新成功");
        }else {
            msg.setStatus(-1);
            msg.setResult("更新失败");
        }
        String s = JsonUtil.toJson(msg);
        return s;
    }
    @ResponseBody("/Courier/delete.do")
    public String delete(HttpServletRequest request,HttpServletResponse response){
        int id = Integer.parseInt(request.getParameter("id"));
        boolean delete = CourierService.delete(id);
        Message msg= new Message();
        if(delete){
            msg.setStatus(0);
            msg.setResult("删除成功");
        }else {
            msg.setStatus(-1);
            msg.setResult("删除失败");
        }
        String s = JsonUtil.toJson(msg);
        return s;
    }
    }

