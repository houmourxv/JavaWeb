package com.zx.controller;

import com.zx.bean.BootstrapTableExpress;
import com.zx.bean.Express;
import com.zx.bean.Message;
import com.zx.bean.ResultData;
import com.zx.mvc.ResponseBody;
import com.zx.service.ExpressService;
import com.zx.util.DateFormatUtil;
import com.zx.util.JsonUtil;
import com.zx.util.UserUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ExpressController {
    private ExpressService service = new ExpressService();
    @ResponseBody("/express/console.do")
    public String console(HttpServletRequest request, HttpServletResponse response){
        Message msg = new Message();
        List<Map<String,Integer>> console = service.console();
        if(console.size()==0){
            msg.setResult("获取失败");
            msg.setResult("-1");
        }else{
            msg.setResult("获取成功");
            msg.setStatus(0);
            msg.setData(console);
        }
        String s = JsonUtil.toJson(msg);
        return  s;
    }
    @ResponseBody("/express/list.do")
    public String list(HttpServletRequest request,HttpServletResponse response){
        //获取其实索引数量
        int offest = Integer.valueOf(request.getParameter("offset"));
        int pageNumber = Integer.valueOf(request.getParameter("pageNumber"));
        List<Express>list = service.findAll(true,offest,pageNumber);
        List<BootstrapTableExpress>list2 = new ArrayList<>();
        for(Express express:list){
            String intime = DateFormatUtil.format(express.getIntime());
            String outtime = express.getOutime()==null?"未出库":DateFormatUtil.format(express.getOutime());
            String code = express.getCode()==null?"已取件": express.getCode();
            String status = express.getStatus()==0?"未取件":"已取件";
            BootstrapTableExpress b = new BootstrapTableExpress(express.getId(),express.getNumber(),express.getUsername(), express.getUserphone(),express.getCompany(),code,intime,outtime,status,express.getSysPhone());
            list2.add(b);
        }
        ResultData<BootstrapTableExpress>data = new ResultData<>();
        data.setRows(list2);
        List<Map<String,Integer>>console = service.console();
        Integer total = console.get(0).get("data1_size");
        data.setTotal(total);
        String s = JsonUtil.toJson(data);
        return s;
    }
    @ResponseBody("/express/insert.do")
    public String insert(HttpServletRequest request,HttpServletResponse response){
        String number = request.getParameter("number");
        String username = request.getParameter("username");
        String userphone = request.getParameter("userPhone");
        String company = request.getParameter("company");
        Express express = new Express(number,username,userphone,company, UserUtil.getUserName(request.getSession()));
        Message msg = new Message();
        boolean flag = ExpressService.insert(express);
        if(flag){
            msg.setStatus(0);
            msg.setResult("快递录入成功");
        }else {
            msg.setStatus(-1);
            msg.setResult("快递录入失败");
        }
        String s =JsonUtil.toJson(msg);
        return s;
    }
    @ResponseBody("/express/find.do")
    public String find(HttpServletRequest request,HttpServletResponse response){
        String number = request.getParameter("number");
        ExpressService.findByNumber(number);
        Express byNUmber = ExpressService.findByNumber(number);
        Message msg = new Message();
        if(byNUmber==null){
            msg.setStatus(-1);
            msg.setResult("单号不存在");
        }else{
            msg.setData(byNUmber);
            msg.setStatus(0);
        }
        String s = JsonUtil.toJson(msg);
        return s;
    }
    @ResponseBody("/express/update.do")
    public String update(HttpServletRequest request,HttpServletResponse response){
        String id = request.getParameter("id");
        String number = request.getParameter("number");
        String userphone = request.getParameter("userphone");
        String username = request.getParameter("username");
        String company = request.getParameter("company");
        int status = Integer.parseInt(request.getParameter("status"));
        Express newExpress = new Express();
        newExpress.setNumber(number);
        newExpress.setUserphone(userphone);
        newExpress.setUsernames(username);
        newExpress.setCompany(company);
        newExpress.setStatus(status);
        Message msg = new Message();
        boolean update = ExpressService.update(Integer.parseInt(id),newExpress);
       if (!update){
           msg.setStatus(-1);
           msg.setResult("更新失败");
       }else{
           msg.setResult("更新成功");
           msg.setStatus(0);
       }
       String s =JsonUtil.toJson(msg);
       return s;

    }
    @ResponseBody("/express/delete.do")
    public String delete(HttpServletRequest request,HttpServletResponse response){
        int id = Integer.parseInt(request.getParameter("id"));
        boolean delete = ExpressService.delete(id);
        Message msg = new Message();
        if (!delete){
            msg.setStatus(-1);
            msg.setResult("删除失败");
        }else{
            msg.setResult("删除成功");
            msg.setStatus(0);
        }
        String s =JsonUtil.toJson(msg);
        return s;
    }
}
