package com.zx.controller;

import com.zx.bean.Message;
import com.zx.mvc.ResponseBody;
import com.zx.service.AdminService;
import com.zx.util.JsonUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

public class AdminController {
    @ResponseBody("/admin/login.do")
    public String login(HttpServletRequest request, HttpServletResponse response){
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        boolean login= AdminService.login(username,password);
        Message msg=null;
        if(login) {
            msg = new Message(0,"登入成功");
            Date date = new Date();
            String remoteAdder = request.getRemoteAddr();
            AdminService.updateLoginTimeAndIp(username, date, remoteAdder);
            request.getSession().setAttribute("adminUsername", username);
        }else {

            msg = new Message(-1,"登入失败");
        }
        String s = JsonUtil.toJson(msg);
        return s;
        }
    }

