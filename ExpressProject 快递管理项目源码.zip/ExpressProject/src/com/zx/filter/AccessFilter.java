//package com.zx.filter;
//
//import com.zx.util.UserUtil;
//
//import javax.servlet.*;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//
//@WebFilter({"/admin/views/*","admin/index.html","/express/*"})
//public class AccessFilter implements Filter {
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException {
//
//    }
//
//    @Override
//    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
//      //判断一下是否登录
//        HttpServletRequest request =(HttpServletRequest) servletRequest;
//        HttpServletResponse response =(HttpServletResponse) servletResponse;
//        String userName = UserUtil.getUserName(request.getSession());
//        if(userName!=null){
//            filterChain.doFilter(servletRequest,servletResponse);
//            return  ;
//        }else{
//            response.sendRedirect("/admin/login.html");
//            return  ;
//        }
//    }
//
//    @Override
//    public void destroy() {
//
//    }
//}
