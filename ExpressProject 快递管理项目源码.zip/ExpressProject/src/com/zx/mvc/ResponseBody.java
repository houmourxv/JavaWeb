package com.zx.mvc;

/**
 * @Author CaesarChang张旭
 * @Date 2021/3/27  9:28 下午
 * @Version 1.0
 */

import java.lang.annotation.*;

/**
 * 被该注解添加的方法,会被用于处理请求,以文字形式返回数据给用户
 */


@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ResponseBody {
    String value();
}
