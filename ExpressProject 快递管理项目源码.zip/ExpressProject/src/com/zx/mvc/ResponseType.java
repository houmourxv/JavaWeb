package com.zx.mvc;

/**
 * @Author CaesarChang张旭
 * @Date 2021/3/27  9:32 下午
 * @Version 1.0
 */



public enum ResponseType {

    TEXT,VIEW;
}
