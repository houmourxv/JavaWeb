package com.zx.mvc;

import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * @Author CaesarChang张旭
 * @Date 2021/3/27  9:33 下午
 * @Version 1.0
 */
public class HandlerMapping {
    private static Map<String,MVCMapping> data=new HashMap<>();

    /**
     * 根据url返回对应的映射
     * @param url
     * @return
     */
    public static  MVCMapping get(String url){
        return data.get(url);
    }



    public static void load(InputStream is){
        Properties ppt=new Properties();
        try {
            ppt.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
    //获取配置文件中=右边的 类的名称
        Collection<Object> values = ppt.values();
        for (Object value : values) {
            String className= (String) value;
            try {
                //加载这个类
                Class c = Class.forName(className);
                //反射创建类的对象
                Object o = c.newInstance();
                //获取这个类的所有public方法
                Method[] methods = c.getMethods();
                for (Method method : methods) {
                    //获取该方法上的全部注解
                    Annotation[] annotations = method.getAnnotations();
                    if (annotations != null) {
                        for (Annotation annotation : annotations) {
                            if (annotation instanceof ResponseBody) {
                                //说明返回字符串给客户端
                                MVCMapping mvcMapping=new MVCMapping(o,method,ResponseType.TEXT);
                                data.put(((ResponseBody) annotation).value(), mvcMapping);

                            } else if (annotation instanceof ResponseView) {
                                //说明返回视图给客户端
                                MVCMapping mvcMapping=new MVCMapping(o,method,ResponseType.VIEW);
                                data.put(((ResponseBody) annotation).value(), mvcMapping);
                            }
                        }
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    /**
     * 映射对象   一个对象对应一个方法
     */
    public static class MVCMapping{

        private Object obj;
        private Method method;
        private ResponseType type;

        public MVCMapping() {
        }

        public MVCMapping(Object obj, Method method, ResponseType type) {
            this.obj = obj;
            this.method = method;
            this.type = type;
        }

        public Object getObj() {
            return obj;
        }

        public void setObj(Object obj) {
            this.obj = obj;
        }

        public Method getMethod() {
            return method;
        }

        public void setMethod(Method method) {
            this.method = method;
        }

        public ResponseType getType() {
            return type;
        }

        public void setType(ResponseType type) {
            this.type = type;
        }
    }

}
