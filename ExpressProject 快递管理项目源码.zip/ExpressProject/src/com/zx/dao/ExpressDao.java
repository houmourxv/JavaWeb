package com.zx.dao;

import com.zx.bean.Express;

import java.util.List;
import java.util.Map;

public interface ExpressDao {
    List<Map<String,Integer>> console();
    List<Express> findAll(boolean limit,int offset,int pageNumber);
    Express findByNumber(String number);
    Express findByUserPhone(String userPhone);
    Express findBySysPhone(String Sysphone);
    boolean insert(Express e);
    boolean update(int id,Express newExpress);
    boolean delete(int id);
    boolean updateStatus(String code);


}
