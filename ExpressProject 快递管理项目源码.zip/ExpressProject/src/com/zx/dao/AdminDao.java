package com.zx.dao;

import java.util.Date;

public interface AdminDao {
    /*根据用户名更改登录时间*/
    void updateLoginTime(String username, Date date, String ip);
    /*检查是否登录成功*/
    boolean login(String username,String password);


}