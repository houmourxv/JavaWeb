package com.zx.dao;

import com.zx.bean.Courier;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface CourierDao {
    boolean insert(Courier courier);
    boolean delete(int id);
    boolean update(int id,Courier courier);
    boolean update_SendNum(String userphone);
    Courier findByPhone(String userphone);
    Courier findByUsername(String username);
    List<Courier> finAll(boolean limit,int offest, int pageNum);
    int getTotal();
    void updateLatestTIme(String username, Date date);
    Map<String,Integer> getConsole();
}
