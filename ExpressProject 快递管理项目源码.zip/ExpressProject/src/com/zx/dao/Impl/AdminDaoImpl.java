package com.zx.dao.Impl;

import com.zx.dao.AdminDao;
import com.zx.util.DruidUtil;

import java.net.ConnectException;
import java.sql.*;
import java.util.Date;

public class AdminDaoImpl implements AdminDao {


    private static final String SQL_UPDATE_LOGIN_TIME ="update Admin set logintime=?,loginip=?where username=?" ;
    private static final String SQL_LOGIN = "select * from Admin where username=? and password=?";

    @Override
    public void updateLoginTime(String username, Date date, String ip) {
        Connection connection=null;
        PreparedStatement state=null;

        try {
            //获取到链接
             connection = DruidUtil.getConnection();
            //预编译SQL语句
             state = connection.prepareStatement(SQL_UPDATE_LOGIN_TIME);

            state.setDate(1,new java.sql.Date(date.getTime()));
            state.setString(2,ip);
            state.setString(3,username);
            state.executeUpdate();
        }catch(SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,state,null);
        }
    }

    @Override
    public boolean login(String username, String password) {
        Connection connection=null;
        PreparedStatement state=null;
        ResultSet resultSet=null;
        try {
            //获取到链接
            connection = DruidUtil.getConnection();
            //预编译SQL语句
            state = connection.prepareStatement(SQL_LOGIN);

            state.setString(1,username);
            state.setString(2,password);
            resultSet = state.executeQuery();
            return resultSet.next();
        }catch(SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,state,resultSet);
        }
        return  false;
    }
}
