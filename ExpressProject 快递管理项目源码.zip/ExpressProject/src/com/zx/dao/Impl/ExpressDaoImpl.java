package com.zx.dao.Impl;

import com.zx.bean.Express;
import com.zx.dao.ExpressDao;
import com.zx.util.DruidUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpressDaoImpl implements ExpressDao {
    private static final String SQL_CONSOLE="select count(id) data1_size,count(to_days(outtime)=to_days(now()) and status=-1 or null) data1_day,count(status=0 or null) data2_size,count(to_days(intime)=to_days(now()) and status=0 or null)data2_day from Express";
    private static final String SQL_FIND_ALL="select * from Express";
    private static final String SQL_FIND_LIMIT="select * from Express limit ?,?";
    private static final String SQL_FIND_BY_CODE="select * from Express where code=?";
    private static final String SQL_FIND_BY_NUMBER="select * from Express where number=?";
    private static final String SQL_FIND_BY_sysPhone="select * from Express where sysPhone=?";
    private static final String SQL_FIND_BY_userPhone="select * from Express where userPhone=?";
    private static final String SQL_INSERT="insert into Express(number,username,userphone,company,code,intime,status,sysPhone) values(?,?,?,?,?,now(),0,?)";
    private static final String SQL_UPDATE="update Express set number?,username?,company=？，status=? where id=?";
    private static final String SQL_UPDATE_STATUS="update Express set status=1,outime=now(),code=-1 where code=?";
    private static final String SQL_DELETE="delete from Express where id=?";



    @Override
    public List<Map<String, Integer>> console() {
    //获取数据库的数据的连接
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ArrayList list = new ArrayList();
        try {
            preparedStatement = connection.prepareStatement(SQL_CONSOLE);
            resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                int data1_size = resultSet.getInt("data1_size");
                int data1_day = resultSet.getInt("data1_day");
                int data2_size = resultSet.getInt("data2_size");
                int data2_day = resultSet.getInt("data2_day");
                Map map = new HashMap();
                map.put("data1_size",data1_size);
                map.put("data1_day",data1_day);
                Map map2 = new HashMap();
                map2.put("data2_size",data2_size);
                map2.put("data2_day",data2_day);
                list.add(map);
                list.add(map2);
            }
        }catch(SQLException throwables){
            throwables.printStackTrace();
        }finally {
              DruidUtil.close(connection,preparedStatement,resultSet);
        }

        return list;
    }

    @Override
    public List<Express> findAll(boolean limit, int offset, int pageNumber) {
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ArrayList list = new ArrayList();
        try {
            if (limit) {
                preparedStatement = connection.prepareStatement(SQL_FIND_LIMIT);
                preparedStatement.setInt(1, offset);
                preparedStatement.setInt(2, pageNumber);
            } else {
                preparedStatement = connection.prepareStatement(SQL_FIND_ALL);
            }
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()) {
                int id = resultSet.getInt("id");
                String number = resultSet.getString("number");
                String username = resultSet.getString("username");
                String userphone = resultSet.getString("userphone");
                String company = resultSet.getString("company");
                String code = resultSet.getString("code");
                Timestamp intime = resultSet.getTimestamp("intime");
                Timestamp outtime = resultSet.getTimestamp("outtime");
                int status = resultSet.getInt("status");
                String sysPhone = resultSet.getString("sysPhone");
                Express e = new Express(id, number, username, userphone, company, code, intime, outtime, status, sysPhone);
                list.add(e);
            }
        }catch (SQLException throwables){
              throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,preparedStatement,resultSet);
        }
        return list;
    }

    @Override
    public Express findByNumber(String number) {
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ArrayList list = new ArrayList();
        Express e=null;
        try {
            preparedStatement = connection.prepareStatement(SQL_FIND_BY_NUMBER);
            preparedStatement.setString(1,number);
            resultSet = preparedStatement.executeQuery();
            if(resultSet.next()) {
                int id = resultSet.getInt("id");

                String username = resultSet.getString("username");
                String userphone = resultSet.getString("userphone");
                String company = resultSet.getString("company");
                String code = resultSet.getString("code");
                Timestamp intime = resultSet.getTimestamp("intime");
                Timestamp outtime = resultSet.getTimestamp("outtime");
                int status = resultSet.getInt("status");
                String sysPhone = resultSet.getString("sysPhone");
                 e = new Express(id, number, username, userphone, company, code, intime, outtime, status, sysPhone);

            }
        }catch (SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,preparedStatement,resultSet);
        }
        return e;
    }

    @Override
    public Express findByUserPhone(String userPhone) {
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ArrayList list = new ArrayList();
        Express e=null;
        try {
            preparedStatement = connection.prepareStatement(SQL_FIND_BY_userPhone );
            preparedStatement.setString(1,userPhone);
            resultSet = preparedStatement.executeQuery();
            if(resultSet.next()) {
                int id = resultSet.getInt("id");
                String number = resultSet.getString("number");
                String username = resultSet.getString("username");
                String userphone = resultSet.getString("userphone");
                String company = resultSet.getString("company");
                String code = resultSet.getString("code");
                Timestamp intime = resultSet.getTimestamp("intime");
                Timestamp outtime = resultSet.getTimestamp("outtime");
                int status = resultSet.getInt("status");
                String sysPhone = resultSet.getString("sysPhone");
                e = new Express(id, number, username, userphone, company, code, intime, outtime, status, sysPhone);

            }
        }catch (SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,preparedStatement,resultSet);
        }
        return e;
    }

    @Override
    public Express findBySysPhone(String Sysphone) {
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ArrayList list = new ArrayList();
        Express e=null;
        try {
            preparedStatement = connection.prepareStatement(SQL_FIND_BY_sysPhone );
            preparedStatement.setString(1,Sysphone);
            resultSet = preparedStatement.executeQuery();
            if(resultSet.next()) {
                int id = resultSet.getInt("id");
                String number = resultSet.getString("number");
                String username = resultSet.getString("username");
                String userphone = resultSet.getString("userphone");
                String company = resultSet.getString("company");
                String code = resultSet.getString("code");
                Timestamp intime = resultSet.getTimestamp("intime");
                Timestamp outtime = resultSet.getTimestamp("outtime");
                int status = resultSet.getInt("status");
                String sysPhone = resultSet.getString("sysPhone");
                e = new Express(id, number, username, userphone, company, code, intime, outtime, status, sysPhone);

            }
        }catch (SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,preparedStatement,resultSet);
        }
        return e;
    }

    @Override
    public boolean insert(Express e) {
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;

        try {
            preparedStatement = connection.prepareStatement(SQL_INSERT);
            preparedStatement.setString(1, e.getNumber());
            preparedStatement.setString(2, e.getUsername());
            preparedStatement.setString(3, e.getUserphone());
            preparedStatement.setString(4, e.getCompany());
            preparedStatement.setString(5, e.getCode());
            preparedStatement.setString(6, e.getSysPhone());
            return preparedStatement.executeUpdate() > 0 ? true : false;
        }catch (SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,preparedStatement,null);
        }
        return false;
    }

    @Override
    public boolean update(int id, Express newExpress) {
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;
        try {
        preparedStatement=connection.prepareStatement(SQL_UPDATE);
        preparedStatement.setString(1,newExpress.getNumber());
        preparedStatement.setString(2,newExpress.getUsername());
        preparedStatement.setString(3,newExpress.getCompany());
        preparedStatement.setInt(4,newExpress.getStatus());
        preparedStatement.setInt(5,id);
        return preparedStatement.executeUpdate()> 0 ?true:false;
        }catch(SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,preparedStatement,null);
        }
        return false;

    }

    @Override
    public boolean delete(int id) {
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement=connection.prepareStatement(SQL_DELETE);
            preparedStatement.setInt(1,id);
            return preparedStatement.executeUpdate()>0?true:false;
        }catch (SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,preparedStatement,null);
        }
        return false;
    }

    @Override
    public boolean updateStatus(String code) {
        Connection connection = DruidUtil.getConnection();
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(SQL_UPDATE_STATUS);
            preparedStatement.setString(1, code);
            return preparedStatement.executeUpdate() > 0 ? true : false;
        }catch (SQLException throwables){
            throwables.printStackTrace();
        }finally {
            DruidUtil.close(connection,preparedStatement,null);
        }
        return false;
    }
}
