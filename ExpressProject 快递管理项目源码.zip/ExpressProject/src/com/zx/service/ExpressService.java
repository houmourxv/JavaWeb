package com.zx.service;

import com.zx.bean.Express;
import com.zx.dao.ExpressDao;
import com.zx.dao.Impl.ExpressDaoImpl;

import java.util.List;
import java.util.Map;

public class ExpressService {
    private static ExpressDao dao = new ExpressDaoImpl();
    public List<Map<String, Integer>> console(){
        return  dao.console();
    }
    public List<Express> findAll(boolean limit,int offset,int pageNumber){
        return dao.findAll(limit,offset,pageNumber);
    }
    public static Express findByNumber(String number){
        return dao.findByNumber(number);
    }
    public Express findByUserPhone(String userphone){
        return dao.findByUserPhone(userphone);
    }
    public Express findBySysPhone(String SysPhone){
        return dao.findBySysPhone(SysPhone);
    }
    public static boolean insert(Express newExpress){
        return  dao.insert(newExpress);
    }
    public static boolean update(int id, Express newExpress){
//        if(newExpress.getUserphone()!=null){
//            dao.delete(id);
//            return  dao.update(id, newExpress);
//        }else {
//            Express byNumber  = dao.findByNumber(newExpress.getNumber());
//            boolean update =dao.update(id, newExpress);
//            if(newExpress.getStatus()==1){
//                updateStatus(byNumber.getCode());
//            }
//            return  update;
//        }
       Express byNumber =  dao.findByNumber(newExpress.getNumber());
       if(newExpress.getStatus()==1){
           updateStatus(byNumber.getCode());
        }
       return dao.update(id,newExpress);
    }
    public static boolean delete(int id){
        return dao.delete(id);
    }
    public static boolean updateStatus(String code){
        return dao.updateStatus(code);
    }
}
