package com.zx.service;

import java.util.Date;
import com.zx.dao.AdminDao;
import com.zx.dao.Impl.AdminDaoImpl;
public class AdminService {
    private static AdminDao dao =new AdminDaoImpl();
    public static void updateLoginTimeAndIp(String username, Date date, String ip){
        dao.updateLoginTime(username,date,ip);
    }
    public static boolean login(String username,String password){
        return  dao.login(username,password);
    }
}
