package com.zx.service;

import com.zx.bean.Courier;
import com.zx.dao.CourierDao;
import com.zx.dao.Impl.CourierDaoImpl;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class CourierService {
    private  static CourierDao courierDao = new CourierDaoImpl();
    public  static boolean insert(Courier courier){
       return courierDao.insert(courier);
    }
    public  static boolean delete(int id){
        return courierDao.delete(id);
    }
    public  static boolean update(int id,Courier courier){
        return courierDao.update(id,courier);
    }
    public  static boolean update_SendNum(String userphone){
        return courierDao.update_SendNum(userphone);
    }
    public  static Courier findByPhone(String userphone){
        return courierDao.findByPhone(userphone);
    }
    public  static Courier findByUsername(String username){
        return courierDao.findByUsername(username);
    }
    public  static List<Courier> findAll(boolean limit, int offset, int pageNum){
        return courierDao.finAll(limit,offset,pageNum);
    }
    public  static int getTotal(){
        return courierDao.getTotal();
    }
    public  static void updateLatestTime(String username, Date date){
        courierDao.updateLatestTIme(username,date);
    }
    public  static Map<String,Integer> getConsole(){
        return courierDao.getConsole();
    }
}
