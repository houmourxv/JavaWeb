package com.zx.bean;

import java.sql.Timestamp;
import java.util.Objects;

public class Courier {
    private  int id;
    private  String username;
    private  String password;
    private  String idCard;
    private  int sendNum;
    private  String userphone;
    private Timestamp register_time;
    private Timestamp lastest_time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getUserphone() {
        return userphone;
    }

    public void setUserphone(String userphone) {
        this.userphone = userphone;
    }

    public int getSendNum() {
        return sendNum;
    }

    public void setSendNum(int sendNumber) {
        this.sendNum = sendNum;
    }

    public Timestamp getRegister_time() {
        return register_time;
    }

    public void setRegister_time(Timestamp register_time) {
        this.register_time = register_time;
    }

    public Timestamp getLastest_time() {
        return lastest_time;
    }

    public void setLastest_time(Timestamp lastest_time) {
        this.lastest_time = lastest_time;
    }

    @Override
    public String toString() {
        return "Courier{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", idCard='" + idCard + '\'' +
                ", sendNum=" + sendNum +
                ", userphone='" + userphone + '\'' +
                ", register_time=" + register_time +
                ", lastest_time=" + lastest_time +
                '}';
    }

    public Courier() {
    }

    public Courier(int id, String username, String password, String idCard, int sendNumber, String userphone, Timestamp register_time, Timestamp lastest_time) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.idCard = idCard;
        this.sendNum = sendNumber;
        this.userphone = userphone;
        this.register_time = register_time;
        this.lastest_time = lastest_time;
    }

    public Courier(int id, String username, String password, String idCard, String userphone) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.idCard = idCard;
        this.userphone = userphone;
    }

    public Courier(int id, String username, String password, String idCard, String userphone, Timestamp register_time) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.idCard = idCard;
        this.userphone = userphone;
        this.register_time = register_time;
    }

    public Courier(String username, String password, String idCard, String userphone) {
        this.username = username;
        this.password = password;
        this.idCard = idCard;
        this.userphone = userphone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Courier)) return false;
        Courier courier = (Courier) o;
        return id == courier.id && sendNum == courier.sendNum && Objects.equals(username, courier.username) && Objects.equals(password, courier.password) && Objects.equals(idCard, courier.idCard) && Objects.equals(userphone, courier.userphone) && Objects.equals(register_time, courier.register_time) && Objects.equals(lastest_time, courier.lastest_time);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, username, password, idCard, sendNum, userphone, register_time, lastest_time);
    }
}
