package com.zx.bean;

import java.sql.Timestamp;

public class BootstrapTableCourier {
    private  int id;
    private  String username;
    private  String password;
    private  String idCard;
    private  String userphone;
    private  int sendNum;
    private String register_time;
    private String lastest_time;

    public BootstrapTableCourier(int id, String username, String password, String idCard,  int sendNum, String userphone,String register_time, String lastest_time) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.idCard = idCard;
        this.userphone = userphone;
        this.sendNum = sendNum;
        this.register_time = register_time;
        this.lastest_time = lastest_time;
    }

    public BootstrapTableCourier() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getUserphone() {
        return userphone;
    }

    public void setUserphone(String userphone) {
        this.userphone = userphone;
    }

    public int getSendNum() {
        return sendNum;
    }

    public void setSendNum(int sendNum) {
        this.sendNum = sendNum;
    }

    public String getRegister_time() {
        return register_time;
    }

    public void setRegister_time(String register_time) {
        this.register_time = register_time;
    }

    public String getLastest_time() {
        return lastest_time;
    }

    public void setLastest_time(String lastest_time) {
        this.lastest_time = lastest_time;
    }
}
